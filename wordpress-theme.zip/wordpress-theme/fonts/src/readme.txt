Converter recommended: https://www.fontsquirrel.com/tools/webfont-generator
Or get Google webfonts from: https://google-webfonts-helper.herokuapp.com/fonts
